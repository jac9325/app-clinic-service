export const environment = {
    production:true,
    URI_BASE_USUARIO_DOMAIN : '',
    URI_BASE_PACIENTE_COLABORADOR_DOMAIN: ''
};
